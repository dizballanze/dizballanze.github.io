var http = require('http');
var url  = require('url');
var messages = [];

http.createServer(function (request, response) { 
  var url_string = request.url;
  params = url.parse(url_string, true).query;
  
  if (params.hasOwnProperty('message')){
      username = (params['username'].length == 0)?'guest':params['username'];
      message = params['message'];
      messages.push(username + ': ' + message);
  }
  
  var id = new Number(params['id']);
  var to, count, from = 0;
  var len = messages.length;
  if (id == -1){
      if (len < 10){
          count = len;
          from = 0;
      }else {
          count = 10;
          from = len - 10;
      }
  }else{
      count = len - id - 1;
      from = id + 1;
  }
  to = from + count - 1;
  ret_messages = [];
  for (i = from; i <= to; i++){
      ret_messages.push({message:messages[i], id:i});
  }
  body = JSON.stringify(ret_messages);
  response.writeHead(200, {
    'Content-Type': 'application/json',
    "Access-Control-Allow-Origin": "*"
     });
  response.end(params.callback + '(\'' + body + '\')'); 
}).listen(8124, "127.0.0.1"); 
console.log('Server running at http://127.0.0.1:8124/');