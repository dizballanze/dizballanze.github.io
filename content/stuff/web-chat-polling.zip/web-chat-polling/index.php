<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru"> 
    <head> 
        <title>Web-Chat-Polling on Node.JS</title> 
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
        <script type="text/javascript" src="jquery.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                
                function load(){
                    if ($(".message-row").size() == 0){
                        var id = -1;
                    }else{
                        var id = $(".message-row:last").data('id');
                    }
                    
                    $.getJSON('http://127.0.0.1:8124/?id=' + id + '&callback=?', function(data){
                        data = $.parseJSON(data);
                        for (i in data){
                            if ($("#mess" + data[i]['id']).size() == 0){
                                $('<div class="message-row" id="mess' + data[i]['id'] + '">' + data[i]['message'] + '</div>').appendTo("#chat-body");
                                $(".message-row:last").data('id', data[i]['id']);
                            }
                        }
                        $("#chat-body").animate({ scrollTop: $("#chat-body").attr("scrollHeight") }, 3000);
                    });
                }
                
                load();
                
                setInterval(load, 2500);
                
                $("input[name=message]").focus();
                
                $("#send-button").click(function(){
                    if ($(".message-row").size() == 0){
                        var id = -1;
                    }else{
                        var id = $(".message-row:last").data('id');
                    }
                    
                    $.getJSON('http://127.0.0.1:8124/?message=' + $("input[name=message]").val() + '&username=' + $("input[name=nick]").val() + '&id=' + id + '&callback=?', function(data){
                        data = $.parseJSON(data);
                        for (i in data){
                            $('<div class="message-row" id="mess' + data[i]['id'] + '">' + data[i]['message'] + '</div>').appendTo("#chat-body");
                            $(".message-row:last").data('id', data[i]['id']);
                        }
                        $("#chat-body").animate({ scrollTop: $("#chat-body").attr("scrollHeight") }, 3000);
                    });
                    $("input[name=message]").val('');
                });
                
                $('input[name=message]').bind('keypress', function(event){
                    if (event.keyCode == 13){
                        $("#send-button").trigger('click');
                    }
                });
            });
        </script>
        <style type="text/css">
            #chat-body {
                width: 480px;
                padding: 10px;
                height: 250px;
                overflow: auto;
                overflow-x: hidden;
                -ms-overflow-x: hidden;
                background-color: #eee;
                border: 1px solid #323232;
                color: #323232;
            }
            input[name=message] {
                width: 500px;
                height: 32px;
                font-size: 26px;
                background-color: #eee;
                color: #323232;
            }
            
            input[name=nick] {
                width: 150px;
                background-color: #eee;
                text-align: center;
                font-style: italic;
                color: #323232;
            }
            
            #wrapper{
                width: 500px;
                border: 1px solid #323232;
                padding: 20px;
                margin-left: auto;
                margin-right: auto;
                background-color: #4A6D94;
                color: #ededed;
                border-radius: 10px;
            }
            
            input[type=submit] {
                width: 100px;
                height: 32px;
                margin-left: 405px;
                margin-top: 5px;
            }
            
            h2 {
                text-align: center;
            }
            
            a {
                color: #ededed;
            }
            
            #footer {
                text-align: center;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <div id="wrapper">
        <h2>Node.JS Web-Chat-Polling</h2>
        <b>Chat:</b><br />
        <div id="chat-body"></div>
        <br/>
        <b>Username:</b><br/><input type="text" name="nick" value="guest" /><br/>
        <b>Message:</b><br/>
        <input type="text" name="message" />
        <br />
        <input type="submit" value="send" id="send-button" />
        <div id="footer">Copyright &copy; 2011 <a href="http://dizballanze.com">Dizballanze</a></div>
        </div>
    </body>
</html>